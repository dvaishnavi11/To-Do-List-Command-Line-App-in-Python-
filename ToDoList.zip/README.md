# To-Do List ✅

A simple Python command-line To-Do list application.

## Features:
- Add new tasks
- View all tasks
- Delete a specific task
- Exit the application

## How to Run:
1. Install Python 3
2. Run the script:
   ```bash
   python todo.py
   ```
